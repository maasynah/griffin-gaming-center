Upload admin.html to the root of your existing GitHub repository.
After publishing, open:
https://maasynah.github.io/griffin-gaming-center/admin.html

IMPORTANT: This is only a front-end prototype. It has no secure login or server storage.
Do not enter real customer information. Add secure authentication, a backend and database
before using an admin panel for real business operations.
